//
//  CrudUno.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit
import Firebase

class CrudUno: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var refMedicamentos: DatabaseReference!
    
    @IBOutlet weak var txtNameMedicamentos: UITextField!
    @IBOutlet weak var textFieldCodigo: UITextField!
    @IBOutlet weak var txtFieldColor: UITextField!
    @IBOutlet weak var lblMensage: UILabel!
    
    @IBOutlet weak var tblMedicamentos: UITableView!
    
    
    var medicamentosList = [MedicamentoModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let medica = medicamentosList[indexPath.row]
        let alertController = UIAlertController(title:medica.name, message:"Dame nuevos datos", preferredStyle:.alert)
        
        let editarAction = UIAlertAction(title: "Editar", style:.default){(_) in
            let id = medica.id
            
            let name  = alertController.textFields?[0].text
            let codigo = alertController.textFields?[1].text
            let color = alertController.textFields?[2].text
            
            self.editarmedicamento(id: id!, name: name!, codigo: codigo!, color: color!)
            
        }
        let eliminarAction = UIAlertAction(title: "Borrar", style:.default){(_) in
            self.borrarMedicamento(id: medica.id!)
            
            
        }
        alertController.addTextField{(textField) in
            textField.text = medica.name
            
        }
        
        alertController.addTextField{(textField) in
            textField.text = medica.codigo
            
        }
        alertController.addTextField{(textField) in
            textField.text = medica.color
            
        }
        
        
        alertController.addAction(editarAction)
        alertController.addAction(eliminarAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func editarmedicamento(id: String, name: String, codigo: String, color: String){
        let medica = [
            "id": id,
            "medicamentoName": name,
            "medicamentoCodigo": codigo,
            "medicamentoColor": color
        
                    ]
        refMedicamentos.child(id).setValue(medica)
        lblMensage.text = "Medicamento Editado"
        
    }
    
    func borrarMedicamento(id: String){
        refMedicamentos.child(id).setValue(nil)
        
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return medicamentosList.count
    }
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerUnoTableViewCell
        let medicamen: MedicamentoModel
        
        medicamen = medicamentosList[indexPath.row]
        
        cell.lblNameMedicamento.text = medicamen.name
        cell.lblCodigoMedicamento.text = medicamen.codigo
        cell.lblColorMedicamento.text = medicamen.color
        return cell
    }
    
    
    @IBAction func btnAddMedicamento(_ sender: UIButton) {
        addMedicamento()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        FirebaseApp.configure()
        
        refMedicamentos = Database.database().reference().child("medicamentos");
        refMedicamentos.observe(DataEventType.value, with:{(snapshot) in
            
            if snapshot.childrenCount>0{
                self.medicamentosList.removeAll()
                
                for medicamento in snapshot.children.allObjects as![DataSnapshot]{
                    let medicamentoObject = medicamento.value as? [String: AnyObject]
                    let medicamentoName = medicamentoObject?["medicamentoName"]
                    let medicamentoCodigo = medicamentoObject?["medicamentoColor"]
                    let medicamentoColor = medicamentoObject?["medicamentoCodigo"]
                    let medicamentoId = medicamentoObject?["id"]
                    
                    
                    let medica = MedicamentoModel(id: medicamentoId as! String?, name: medicamentoName as! String?, codigo: medicamentoCodigo as! String?, color: medicamentoColor as! String?)
                    
                    
                    self.medicamentosList.append(medica)
                }
                self.tblMedicamentos.reloadData()
                
            }
            
        })
        
    }
    
    func addMedicamento(){
        let key  = refMedicamentos.childByAutoId().key
        
        let medicamento  = ["id":key,
                            "medicamentoName": txtNameMedicamentos.text! as String,
                            "medicamentoCodigo": textFieldCodigo.text! as String,
                            "medicamentoColor": txtFieldColor.text! as String
        
                            ]
        
        refMedicamentos.child(key!).setValue(medicamento)
        lblMensage.text  = "Medicamento Guardado"
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
