//
//  ViewControllerTresTableViewCell.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/7/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit

class ViewControllerTresTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblNamePrograma: UILabel!
    
    @IBOutlet weak var lblTipoPrograma: UILabel!
    
    @IBOutlet weak var lblEncargado: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
