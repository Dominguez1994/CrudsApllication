//
//  MedicamentoModel.swift
//  
//
//  Created by Francisco Dominguez on 5/6/19.
//

class MedicamentoModel{
    var id: String?
    var name: String?
    var codigo: String?
    var color: String?
    
    init(id: String?, name: String?, codigo: String?, color: String?){
        
        self.id = id;
        self.name = name;
        self.codigo = codigo;
        self.color = color;
        
    }
    
}
