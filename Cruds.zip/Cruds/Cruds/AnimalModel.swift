//
//  AnimalModel.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

class AnimalModel{
    var id: String?
    var name: String?
    var tipo: String?
    var peso: String?
    var color: String?
    
    
    init(id:String?, name: String?, tipo: String?, peso: String?, color: String?){
        self.id = id;
        self.name = name;
        self.tipo = tipo;
        self.peso = peso;
        self.color = color;
        
    }
    
}
